const mongoose = require("mongoose");

const { Schema } = mongoose;

const countSchema = new Schema({
  title: String,
  count: String,
  date: String
});

module.exports = Count = mongoose.model("user", countSchema); 